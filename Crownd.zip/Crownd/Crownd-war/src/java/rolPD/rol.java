package rolPD;

public class rol {
    private int rolId;
    private String name;

    public rol(int rolId, String name) {
        this.rolId = rolId;
        this.name = name;
    }

    public rol(){
        
    }
    
    public int getRolId() {
        return rolId;
    }

    public void setRolId(int rolId) {
        this.rolId = rolId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    
}
