/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package donante;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author larra
 */
@Entity
@Table
@NamedQueries(@NamedQuery(name="user.getAll", query="SELECT e FROM sponsor e"))
public class sponsor implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column
    private int sponsorId;
    @Column
    private int userId;
    @Column
    private int projectId;

    public sponsor(int sponsorId, int userId, int projectId) {
        this.sponsorId = sponsorId;
        this.userId = userId;
        this.projectId = projectId;
    }
    
    public sponsor(){
        
    }

    public int getSponsorId() {
        return sponsorId;
    }

    public void setSponsorId(int sponsorId) {
        this.sponsorId = sponsorId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getProjectId() {
        return projectId;
    }

    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }
    
    
    
   
}
