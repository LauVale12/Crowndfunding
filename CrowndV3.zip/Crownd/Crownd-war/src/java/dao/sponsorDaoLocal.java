package dao;

import java.util.List;
import javax.ejb.Local;
import donante.sponsor;
/**
 *
 * @author larra
 */

@Local
public interface sponsorDaoLocal {
    
    void addSponsor(sponsor donante);
    
    void editSponsor(sponsor donante);
    
    void deleteSponsor(int sponsorId);
    
    sponsor searchSponsor(int sponsorId);
    
    List<sponsor> sponsors();
    
    
}
