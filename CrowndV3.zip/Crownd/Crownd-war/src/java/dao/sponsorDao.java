package dao;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import donante.sponsor;
/**
 *
 * @author larra
 */

@Stateless
public class sponsorDao implements sponsorDaoLocal {

    @PersistenceContext
    private EntityManager pr;
    
    @Override
    public void addSponsor(sponsor donante) {
        pr.persist(donante);
    }

    @Override
    public void editSponsor(sponsor donante) {
        pr.merge(donante);
    }

    @Override
    public void deleteSponsor(int sponsorId) {
        pr.remove(sponsorId);
    }

    @Override
    public sponsor searchSponsor(int sponsorId) {
        return pr.find(sponsor.class, sponsorId);
    }

    @Override
    public List<sponsor> sponsors() {
        return pr.createNamedQuery("sponsor.getAll").getResultList();
    }
    
}
