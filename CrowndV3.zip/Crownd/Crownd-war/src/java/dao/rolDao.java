package dao;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless
public class rolDao implements rolDaoLocal {
    @PersistenceContext
    private EntityManager rl;
    
    
}
